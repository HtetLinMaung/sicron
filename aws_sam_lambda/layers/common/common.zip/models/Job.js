"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const jobSchema = new mongoose_1.Schema({
    jobid: {
        type: String,
        required: true,
    },
    jobtype: {
        type: String,
        default: "api",
    },
    rule: {
        type: mongoose_1.Schema.Types.Mixed,
        default: {},
    },
    options: {
        type: mongoose_1.Schema.Types.Mixed,
        default: {},
    },
    status: {
        type: String,
        enum: ["active", "cancel", "start", "finish", "fail"],
        default: "active",
    },
    repeatcount: {
        type: Number,
        default: 0,
    },
    finishedcount: {
        type: Number,
        default: 0,
    },
}, { timestamps: true });
exports.default = (0, mongoose_1.model)("Job", jobSchema);
//# sourceMappingURL=Job.js.map