"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_schedule_1 = require("node-schedule");
const starless_http_1 = __importDefault(require("starless-http"));
const Job_1 = __importDefault(require("../models/Job"));
const JobHistory_1 = __importDefault(require("../models/JobHistory"));
const variables_1 = require("../variables");
const connect_mongoose_1 = __importDefault(require("./connect-mongoose"));
function scheduleApiJob(jobid, rule, options) {
    return (0, node_schedule_1.scheduleJob)(typeof rule == "string" ? new Date(rule) : rule, async () => {
        await (0, connect_mongoose_1.default)();
        let job = await Job_1.default.findOne({ jobid, status: "active" });
        if (!job) {
            return false;
        }
        if (job.repeatcount && job.repeatcount >= job.finishedcount) {
            if (variables_1.jobs[jobid]) {
                variables_1.jobs[jobid].cancel();
            }
            return false;
        }
        job.status = "start";
        await job.save();
        const jobHistory = new JobHistory_1.default({
            job: job._id,
        });
        try {
            const { url } = options;
            const body = options.body || {};
            const headers = options.headers || {};
            const params = options.query || {};
            const method = options.method ? options.method.toLowerCase() : "get";
            let response = null;
            let err = null;
            if (method == "get") {
                [response, err] = await starless_http_1.default.get(url, {
                    params,
                    headers,
                });
            }
            else if (method == "post") {
                [response, err] = await starless_http_1.default.post(url, body, {
                    params,
                    headers,
                });
            }
            else if (method == "put") {
                [response, err] = await starless_http_1.default.put(url, body, {
                    params,
                    headers,
                });
            }
            else if (method == "patch") {
                [response, err] = await starless_http_1.default.patch(url, body, {
                    params,
                    headers,
                });
            }
            else if (method == "delete") {
                [response, err] = await starless_http_1.default.delete(url, {
                    params,
                    headers,
                });
            }
            if (err || response.status >= 400) {
                job.status = "fail";
                await job.save();
                jobHistory.log = {};
                if (response) {
                    jobHistory.log = {
                        status: response.status,
                        responseData: response.data,
                        errMessage: null,
                    };
                }
                else {
                    jobHistory.log = {
                        status: null,
                        responseData: null,
                        errMessage: err.message,
                    };
                }
            }
            else {
                jobHistory.log = {
                    status: response.status,
                    responseData: response.data,
                    errMessage: null,
                };
                job.status = "finish";
                await job.save();
                await Job_1.default.findOneAndUpdate({ _id: job._id }, {
                    $inc: {
                        finishedcount: 1,
                    },
                });
            }
            await jobHistory.save();
        }
        catch (err) {
            job.status = "fail";
            jobHistory.log = {
                status: null,
                responseData: null,
                errMessage: err.message,
            };
            await job.save();
            await jobHistory.save();
        }
    });
}
exports.default = scheduleApiJob;
//# sourceMappingURL=schedule-api-job.js.map