"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.jobs = void 0;
exports.jobs = {};
//# sourceMappingURL=variables.js.map